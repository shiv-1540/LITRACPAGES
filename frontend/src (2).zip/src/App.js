import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Login from './components/LOGIN/login.js';
import SignUp from './components/LOGIN/signup.js';
import Home from './components/HOME/Home.js';
import Profile from './components/PROFILE/Profile'; // Assuming you have a Profile component
import CreatePost from './components/POST/createpost.js';
import MainProfile from './components/POST/mainprofile.js';
import "./components/POST/style.css";
import UserPosts from './components/POST/postss.js';

function App() {
  return (
    <div className="App">
       <Router>
         <Routes>
            <Route path="/" element={<Navigate to="/login" />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<SignUp />} />
            <Route path="/home" element={<Home />} />
            <Route path="/profile" element={<MainProfile />} />
            <Route path="/createpost" element={<CreatePost />}/>
            <Route path="/userpost" element={<UserPosts/>} />
          </Routes>
        </Router>
    </div>
  );
}

export default App;
