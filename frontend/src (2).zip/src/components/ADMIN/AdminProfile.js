import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faThumbsUp, faThumbsDown } from '@fortawesome/free-solid-svg-icons';
import './AdminProfile.css';

const AdminProfile = () => {
  const [darkMode, setDarkMode] = useState(false);
  const [userDisabled, setUserDisabled] = useState(false);
  const [postDisabled1, setPostDisabled1] = useState(false);
  const [postDisabled2, setPostDisabled2] = useState(false);
  const [expandPost1, setExpandPost1] = useState(false);
  const [expandPost2, setExpandPost2] = useState(false);

  const toggleDarkMode = () => setDarkMode(!darkMode);
  const toggleUser = () => setUserDisabled(!userDisabled);
  const togglePost1 = () => setPostDisabled1(!postDisabled1);
  const togglePost2 = () => setPostDisabled2(!postDisabled2);
  const toggleExpandPost1 = () => setExpandPost1(!expandPost1);
  const toggleExpandPost2 = () => setExpandPost2(!expandPost2);

  return (
    <div className={`container ${darkMode ? 'dark-mode' : ''}`}>
      <header className="d-flex justify-content-between align-items-center my-4">
        <h1>Profile</h1>
        <button className="btn btn-secondary" onClick={toggleDarkMode}>Toggle Dark Mode</button>
      </header>

      <div className="admin-controls">
        <img src="https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Profile Picture" className="profile-picture" />
        <span className="username">Sachin</span>
        <button className={`btn btn-sm ${userDisabled ? 'btn-success' : 'btn-danger'}`} onClick={toggleUser}>
          {userDisabled ? 'Enable User' : 'Disable User'}
        </button>
      </div>

      <div className="post-card">
        <div className="post-header">
          <img src="https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Profile Picture" />
          <span className="username">Sachin</span><span>posted </span><span className="text-muted"> on July 1, 2024</span>
        </div>
        <div className="post-image-container">
          <img src="https://images.pexels.com/photos/547115/pexels-photo-547115.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Post Image" />
          <div className="post-image-overlay">Blog Title 1</div>
        </div>
        <div className="post-body">
          <div className={`post-body-content ${expandPost1 ? 'expand' : ''}`}>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam.</p>
          </div>
          <a href="#" className="read-more" onClick={(e) => { e.preventDefault(); toggleExpandPost1(); }}>
            {expandPost1 ? 'Read less' : 'Read more'}
          </a>
        </div>
        <div className="post-footer">
          <div>
            <button className={`btn btn-sm ${postDisabled1 ? 'btn-warning' : 'btn-success'}`} onClick={togglePost1}>
              {postDisabled1 ? 'Enable Post' : 'Disable Post'}
            </button>
            <button className="btn btn-info btn-sm">Comments</button>
          </div>
          <div>
            <button className="btn btn-primary btn-sm"><FontAwesomeIcon icon={faThumbsUp} /> Like</button>
            <button className="btn btn-secondary btn-sm"><FontAwesomeIcon icon={faThumbsDown} /> Dislike</button>
          </div>
        </div>
      </div>

      <div className="post-card">
        <div className="post-header">
          <img src="https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Profile Picture" />
          <span className="username">Sachin</span><span>posted</span><span className="text-muted"> on July 2, 2024</span>
        </div>
        <div className="post-image-container">
          <img src="https://images.pexels.com/photos/250591/pexels-photo-250591.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Post Image" />
          <div className="post-image-overlay">Blog Title 2</div>
        </div>
        <div className="post-body">
          <div className={`post-body-content ${expandPost2 ? 'expand' : ''}`}>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam.</p>
          </div>
          <a href="#" className="read-more" onClick={(e) => { e.preventDefault(); toggleExpandPost2(); }}>
            {expandPost2 ? 'Read less' : 'Read more'}
          </a>
        </div>
        <div className="post-footer">
          <div>
            <button className={`btn btn-sm ${postDisabled2 ? 'btn-warning' : 'btn-success'}`} onClick={togglePost2}>
              {postDisabled2 ? 'Enable Post' : 'Disable Post'}
            </button>
            <button className="btn btn-info btn-sm">Comments</button>
          </div>
          <div>
            <button className="btn btn-primary btn-sm"><FontAwesomeIcon icon={faThumbsUp} /> Like</button>
            <button className="btn btn-secondary btn-sm"><FontAwesomeIcon icon={faThumbsDown} /> Dislike</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminProfile;
