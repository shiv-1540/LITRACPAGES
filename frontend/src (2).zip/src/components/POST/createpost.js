import axios from "axios";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Modal, Button } from 'react-bootstrap';

function CreatePost() {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [username, setUsername] = useState('');
  const [type, setType] = useState('');
  const [image, setImage] = useState(null);
  const [message, setMessage] = useState('');
  const [showCreatePostModal, setShowCreatePostModal] = useState(false);

  const handleClose = () => setShowCreatePostModal(false);
  const handleShow = () => setShowCreatePostModal(true);

  const uploadPost = async () => {
    const formData = new FormData();
    formData.append('title', title);
    formData.append('content', content);
    formData.append('username', username);
    formData.append('type', type);
    formData.append('image', image);

    try {
      const response = await axios.post("http://localhost:3001/posty", formData, {
        headers: { 'Content-Type': "multipart/form-data" },
      });

      if (response.data.message) {
        setMessage(response.data.message);
        setTimeout(() => {
          navigate('/MainProfile');
        }, 2000);
      }
    } catch (error) {
      console.error('Error uploading post:', error);
      setMessage('Error uploading post');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await uploadPost();
  };

  return (
    <div className="container">
      <Button variant="primary" onClick={handleShow}>
        Create New Post
      </Button>

      <Modal show={showCreatePostModal} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Create Post</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p className="text-warning">{message}</p>
          <form onSubmit={handleSubmit}>
            <div className="mb-3 row">
              <label className="col-sm-3">Title</label>
              <div className="col-sm-9">
                <input type="text" className="form-control" onChange={(e) => setTitle(e.target.value)} />
              </div>
            </div>
            <div className="mb-3 row">
              <label className="col-sm-3">Content</label>
              <div className="col-sm-9">
                <input type="text" className="form-control" onChange={(e) => setContent(e.target.value)} />
              </div>
            </div>
            <div className="mb-3 row">
              <label className="col-sm-3">Username</label>
              <div className="col-sm-9">
                <input type="text" className="form-control" onChange={(e) => setUsername(e.target.value)} />
              </div>
            </div>
            <div className="mb-3 row">
              <label className="col-sm-3">Type</label>
              <div className="col-sm-9">
                <input type="text" className="form-control" onChange={(e) => setType(e.target.value)} />
              </div>
            </div>
            <div className="mb-3 row">
              <label className="col-sm-3">Image</label>
              <div className="col-sm-9">
                <input type="file" className="form-control" onChange={(e) => setImage(e.target.files[0])} />
              </div>
            </div>
            <div className="mb-3 row">
              <label className="col-sm-3"></label>
              <div className="col-sm-9">
                <button type="submit" className="btn btn-success">Submit</button>
              </div>
            </div>
          </form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default CreatePost;
