import React from 'react';
import { Button } from 'react-bootstrap';

const SettingsMenu = ({ show, handleClose }) => {
  return (
    <div className={`settings-menu ${show ? 'open' : ''}`} id="settingsMenu">
      <Button className="close-settings-button" onClick={handleClose}>
        &times;
      </Button>
      <h4>Settings</h4>
      <ul className="list-group">
        <li className="list-group-item">Profile Settings</li>
        <li className="list-group-item">Account Settings</li>
        <li className="list-group-item">Privacy Settings</li>
        <li className="list-group-item">Notification Settings</li>
      </ul>
    </div>
  );
};

export default SettingsMenu;
