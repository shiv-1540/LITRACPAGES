import React, { useState } from 'react';
import { Modal, Button, Form } from 'react-bootstrap';

const Profile = ({ user, openEditProfileModal }) => {
  return (
    <div className="profile-header">
      <div className="left">
        <img src={user.profilePicture} alt="Profile Picture" className="profile-picture" />
        <div>
          <h3>{user.username}</h3>
          <p>{user.fullName}</p>
        </div>
        <Button onClick={openEditProfileModal} variant="outline-dark">
          <i className="fas fa-edit"></i> Edit Profile
        </Button>
      </div>
    </div>
  );
};

export default Profile;
