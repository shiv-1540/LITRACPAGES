import React, { useEffect, useState } from "react";
import axios from "axios";

function UserPosts() {
  const username='shiv1540';
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);


  const fetchPosts = async () => {
    try {
      console.log(username);
      const response = await fetch('http://localhost:3001/user-posts', {
        method:'GET',
        headers: {
            'Content-Type': 'application/json'
        },
        body:JSON.stringify({username:username})
      })
      

      setPosts(response.data);
      console.log(posts);
    } 
    catch (err) {
      console.error('Error fetching user posts:', err);
      setError('Error fetching user posts');
    } 
    finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    console.log(posts);

    fetchPosts();
  }, []);

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <p>{error}</p>;
  }

  return (
    <div className="container">
    
      <h5>{username}'s Posts</h5>
      {posts.length === 0 ? (
        <p>No posts found</p>
      ) : (
        posts.map(post => (
          <div key={post.post_id} className="card mb-3">
            <div className="card-body">
              <h5 className="card-title">{post.title}</h5>
              <p className="card-text">{post.content}</p>
              {post.img && <img src={`data:image/jpeg;base64,${Buffer.from(post.img).toString('base64')}.png`} alt="Post Image" className="img-fluid" />}
              <p className="card-text"><small className="text-muted">Posted on {new Date(post.created_at).toLocaleString()}</small></p>
            </div>
          </div>
        ))
      )}
    </div>
  );
}

export default UserPosts;
