import React, { useState } from 'react';
import { Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import Profile from './profile.js';
import PostModal from './postmodal.js';
import EditProfileModal from './editprofile.js';
import SettingsMenu from './settingsmenu.js';
import CreatePost from './createpost.js';
import UserPosts from './postss.js';


const MainProfile = () => {
  const [showPostModal, setShowPostModal] = useState(false);
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);
  const [showSettingsMenu, setShowSettingsMenu] = useState(false);

  const user = {
    profilePicture: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    username: 'Sayujio',
    fullName: 'Sayuj Singh',
    bio: 'A photographer and writer with a passion for capturing the world and telling stories that hit different. Armed with a camera and a pen, I\'m all about creating content that vibes.'
  };

  const handleShowPostModal = () => setShowPostModal(true);
  const handleClosePostModal = () => setShowPostModal(false);

  return (
    <div className="container mt-5">
      <Button
        className="settings-button"
        variant="outline-dark"
        onClick={() => setShowSettingsMenu(true)}
      >
        <i className="fas fa-cog"></i> Settings
      </Button>
      <Profile user={user} openEditProfileModal={() => setShowEditProfileModal(true)} />
      <div className="mb-4">
        <h4>About</h4>
        <p>{user.bio}</p>
        <p>🎃📸</p>
      </div>
      <div className="action-buttons mb-4">
        <Button variant="outline-dark" onClick={handleShowPostModal}>
          <i className="fas fa-plus"></i> Create Post
        </Button>
        <Button variant="outline-dark">
          <i className="fas fa-archive"></i> View Archive
        </Button>
      </div>
      {/* Blog entries can go here */}
      <CreatePost show={showPostModal} handleClose={handleClosePostModal} />
      <EditProfileModal
        show={showEditProfileModal}
        handleClose={() => setShowEditProfileModal(false)}
        user={user}
      />

       <UserPosts/>
      <SettingsMenu show={showSettingsMenu} handleClose={() => setShowSettingsMenu(false)} />
    </div>
  );
};

export default MainProfile;
