import React, { useState } from 'react';
import './Home.css'; // Import custom CSS for styling
import { useNavigate } from 'react-router-dom';


const commentsData = {
  "MOUNTAINS": [
    { username: "Alice", comment: "Great post! Mountains are my favorite." },
  ],
  "FLOWERS": [
    { username: "Olivia", comment: "Flowers are so colorful and therapeutic." },
  ],
  "DEEP OCEANS": [
    { username: "Charlotte", comment: "Ocean life is so fascinating. Thanks for the article." },
  ]
};


const BlogCard = ({ title, subtitle, content, imgSrc, userProfile, username, date, onShowComments }) => {
  const [isTruncated, setIsTruncated] = useState(true);
  const [fullContent, setFullContent] = useState(content);
  const [truncatedContent, setTruncatedContent] = useState(content.slice(0, 200) + '...');

  const handleReadMore = () => {
    setIsTruncated(!isTruncated);
  };
  

  return (
    <div className="card mb-4">
      <img src={imgSrc} className="card-img-top rounded-0" alt={title} />
      <div className="card-body">
        <div className="d-flex align-items-center mb-3">
          <img src={userProfile} alt="User Profile" className="profile-picture2 mr-2"/>
          <p className="mb-0">{username}</p>
        </div>
        <h3 className="card-title"><b>{title}</b></h3>
        <h5 className="card-subtitle mb-2 text-muted">{subtitle}, <span className="text-muted">{date}</span></h5>
        <p className="card-text blog-content">{isTruncated ? truncatedContent : fullContent}</p>
        <button className="btn btn-outline-primary btn-sm read-more-btn" onClick={handleReadMore}>
          {isTruncated ? 'READ MORE »' : 'READ LESS «'}
        </button>
        <div className="d-flex justify-content-between align-items-center mt-2">
          <span className="comment-count" onClick={onShowComments}><i className="fas fa-comments"></i> <b>10</b></span>
          <div>
            <span className="like-count"><i className="fa fa-heart like-icon"></i> <b>0</b> </span>
            <span className="dislike-icon"><i className="fa fa-thumbs-down"></i> <b>0</b> </span>
          </div>
        </div>
      </div>
    </div>
  );
};

const CommentsModal = ({ show, onHide, title }) => {
  const comments = commentsData[title] || [];

  return (
    <div className={`modal fade ${show ? 'show' : ''}`} style={{ display: show ? 'block' : 'none' }} tabIndex="-1" role="dialog" aria-labelledby="commentsModalLabel" >
      <div className="modal-dialog modal-dialog-centered" role="document">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title" id="commentsModalLabel">Comments</h5>
            <button type="button" className="close" onClick={onHide} aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div className="modal-body">
            {comments.length === 0 ? (
              <p className="no-comments">No comments yet. Be the first to comment!</p>
            ) : (
              <div className="comments-list">
                {comments.map((comment, index) => (
                  <div className="mb-2" key={index}>
                    <div className="d-flex align-items-center">
                      <div><img src="https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Profile" className="profile-picture2 mr-2" /></div>
                      <p className="mb-0 font-weight-bold">{comment.username}</p>
                    </div>
                    <p className="mb-0 ml-4">{comment.comment}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const Home = () => {
  const [showCommentsModal, setShowCommentsModal] = useState(false);
  const [selectedTitle, setSelectedTitle] = useState('');

  const handleShowComments = (title) => {
    setSelectedTitle(title);
    setShowCommentsModal(true);
  };
  const navigate = useNavigate();
  const handleShowProfile =()=>{
    navigate('/profile');
}

  const handleCloseComments = () => {
    setShowCommentsModal(false);
  };

  return (
    <div className="container" id='Home'>
      <header className="text-center my-4 d-flex justify-content-between align-items-center">
        <div className="text-center">
          <h1><b>LITARC</b> <span className="playwrite-cl">PAGES</span></h1>
          <p style={{ fontSize: '0.75em', marginTop: 0 }}>BRINGING WORDS TO LIFE</p>
        </div>
        <span className="badge" style={{ fontSize: '1.5em' }}>Sayuj Singh
          <a href="#">
            <img src="https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Profile Picture" className="profile-picture" onClick={handleShowProfile}/>
          </a>
        </span>
      </header>

      <div className="row">
        <div className="col-lg-8 col-md-12 mb-4 blog-entries">
          <BlogCard
            title="MOUNTAINS"
            subtitle="Majestic Heights"
            content="Explore the grandeur of towering mountains and the serenity they offer. From breathtaking peaks to tranquil valleys, mountains hold a unique charm that captivates the heart of every adventurer."
            imgSrc="https://images.pexels.com/photos/547115/pexels-photo-547115.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
            userProfile="https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
            username="Sayujio"
            date="June 7, 2024"
            onShowComments={() => handleShowComments('MOUNTAINS')}
          />
          
          <BlogCard
            title="FLOWERS"
            subtitle="Blooming Beauty"
            content="Dive into the vibrant world of flowers. Discover the diversity of flora, from delicate petals to bold blossoms, each flower tells a story of nature's splendor and the cycle of life."
            imgSrc="https://images.pexels.com/photos/250591/pexels-photo-250591.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750"
            userProfile="https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
            username="RajMehta"
            date="June 2, 2024"
            onShowComments={() => handleShowComments('FLOWERS')}
          />

          <BlogCard
            title="DEEP OCEANS"
            subtitle="Mysteries Beneath"
            content="Uncover the mysteries of the deep oceans. From the stunning coral reefs to the enigmatic sea creatures, the ocean depths are a world of wonder and intrigue, waiting to be explored. Lorem ipsum dolor sit amet..."
            imgSrc="https://images.pexels.com/photos/5326990/pexels-photo-5326990.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
            userProfile="https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
            username="JiyaShah"
            date="May 15, 2024"
            onShowComments={() => handleShowComments('DEEP OCEANS')}
          />
        </div>

        <div className="col-lg-4 col-md-12 popular-posts mb-4">
          <div className="card mb-4">
            <div className="card-header">
              <h4>Popular Posts</h4>
            </div>
            <ul className="list-group list-group-flush">
              <li className="list-group-item">
                <img src="https://images.pexels.com/photos/547115/pexels-photo-547115.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" alt="Popular Post" className="popular-post-img" />
                <p className="popular-post-title">MOUNTAINS</p>
              </li>
              <li className="list-group-item">
                <img src="https://images.pexels.com/photos/250591/pexels-photo-250591.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" alt="Popular Post" className="popular-post-img" />
                <p className="popular-post-title">FLOWERS</p>
              </li>
              <li className="list-group-item">
                <img src="https://images.pexels.com/photos/5326990/pexels-photo-5326990.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" alt="Popular Post" className="popular-post-img" />
                <p className="popular-post-title">DEEP OCEANS</p>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <CommentsModal show={showCommentsModal} onHide={handleCloseComments} title={selectedTitle} />
    </div>
  );
};

export default Home;
