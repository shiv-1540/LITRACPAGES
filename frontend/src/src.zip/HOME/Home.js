import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Spinner, Alert, Button, Card } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Home.css'; // Import custom CSS for proper styling

const BlogCard = ({ post_id, title, content, imgSrc, userProfile, username, date, initialLikes, initialDislikes, onShowComments }) => {
  const [likes, setLikes] = useState(initialLikes);
  const [dislikes, setDislikes] = useState(initialDislikes);
  const [hasLiked, setHasLiked] = useState(false);
  const [hasDisliked, setHasDisliked] = useState(false);

  useEffect(() => {
    const user_id = localStorage.getItem('user_id');

    if (user_id) {
      // Load like/dislike state from localStorage
      const storedHasLiked = localStorage.getItem(`post_${post_id}_liked_${user_id}`);
      const storedHasDisliked = localStorage.getItem(`post_${post_id}_disliked_${user_id}`);

      if (storedHasLiked === 'true') {
        setHasLiked(true);
      }
      if (storedHasDisliked === 'true') {
        setHasDisliked(true);
      }

      // Fetch and update like/dislike counts from the server
      const checkUserReaction = async () => {
        try {
          const response = await fetch(`http://localhost:3001/post/${post_id}/reaction/${user_id}`, { method: 'GET' });
          const data = await response.json();
          if (data.hasLiked && !storedHasLiked) {
            setHasLiked(true);
            localStorage.setItem(`post_${post_id}_liked_${user_id}`, 'true');
          }
          if (data.hasDisliked && !storedHasDisliked) {
            setHasDisliked(true);
            localStorage.setItem(`post_${post_id}_disliked_${user_id}`, 'true');
          }
        } catch (error) {
          console.error('Error fetching user reaction:', error);
        }
      };
      checkUserReaction();
    }
  }, [post_id]);

  const handleLike = async () => {
    const user_id = localStorage.getItem('user_id');
    if (user_id) {
      try {
        const response = await fetch(`http://localhost:3001/post/${post_id}/like/${user_id}`, { method: 'POST' });
        if (response.ok) {
          setLikes(prevLikes => prevLikes + 1);
          setHasLiked(true);
          localStorage.setItem(`post_${post_id}_liked_${user_id}`, 'true');
          if (hasDisliked) {
            setDislikes(prevDislikes => prevDislikes - 1);
            setHasDisliked(false);
            localStorage.removeItem(`post_${post_id}_disliked_${user_id}`);
          }
        }
      } catch (error) {
        console.error('Error liking post:', error);
      }
    }
  };

  const handleDislike = async () => {
    const user_id = localStorage.getItem('user_id');
    if (user_id) {
      try {
        const response = await fetch(`http://localhost:3001/post/${post_id}/dislike/${user_id}`, { method: 'POST' });
        if (response.ok) {
          setDislikes(prevDislikes => prevDislikes + 1);
          setHasDisliked(true);
          localStorage.setItem(`post_${post_id}_disliked_${user_id}`, 'true');
          if (hasLiked) {
            setLikes(prevLikes => prevLikes - 1);
            setHasLiked(false);
            localStorage.removeItem(`post_${post_id}_liked_${user_id}`);
          }
        }
      } catch (error) {
        console.error('Error disliking post:', error);
      }
    }
  };

  return (
    <Card className="mb-4 blog-card">
      {imgSrc && <Card.Img variant="top" src={imgSrc} className="card-img-top rounded-0" />}
      <Card.Body>
        <Card.Title>{title}</Card.Title>
        <Card.Text>{content}</Card.Text>
        <div className="d-flex justify-content-between align-items-center mt-2">
          <Button variant="link" onClick={onShowComments}>
            <i className="fas fa-comments"></i> Comments
          </Button>
          <div className="d-flex align-items-center justify-content-center">
            <img src={userProfile} alt={username} className="profile-picture-small rounded-circle me-2" />
            <span className="username-text text-dark">{username}</span>
          </div>
        </div>
        <div className="d-flex justify-content-between align-items-center mt-2">
          <Button
            variant={hasLiked ? "primary" : "outline-primary"}
            onClick={handleLike}
            disabled={hasLiked}
          >
            <i className="fas fa-thumbs-up"></i> {likes}
          </Button>
          <Button
            variant={hasDisliked ? "danger" : "outline-danger"}
            onClick={handleDislike}
            disabled={hasDisliked}
          >
            <i className="fas fa-thumbs-down"></i> {dislikes}
          </Button>
        </div>
      </Card.Body>
      <Card.Footer className="text-muted">Posted on {date}</Card.Footer>
    </Card>
  );
};



const Home = () => {
  const user_id = localStorage.getItem('user_id');
  const username=localStorage.getItem('username');

  const navigate = useNavigate();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchHomeData = async () => {
      try {
        const response = await fetch('http://localhost:3001/home/posts', {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
        });

        const data = await response.json();

        if (data.posts) {
          setPosts(data.posts);
          //console.log("Likes: ",data.posts[0].n_likes);
        } else {
          setError('Unexpected response format');
        }
      } catch (error) {
        setError('Error fetching home data');
      } finally {
        setLoading(false);
      }
    };

    fetchHomeData();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('user_id');
    localStorage.removeItem('username');
    localStorage.removeItem('roleid');
    localStorage.removeItem('isLoggedIn');
    navigate('/login');
  };

  return (
    <div className="container" id="Home">
    <header className="fixed-header">
    <div className="logo-container">
      <b>LITARC-PAGES</b>
      <p className="tagline">BRINGING WORDS TO LIFE</p>
      <p> {username}</p>
    </div>
    <div className="d-flex justify-content-center align-items-center">
      <Button className="btn btn-danger" onClick={handleLogout}>Logout</Button>
      <Button variant="link" onClick={() => navigate(`/profile/${user_id}`)}>
        <img
          src="https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
          alt="Profile Picture"
          className="profile-picture rounded-circle ml-3"
        />
        
       
      </Button>
    </div>
  </header>
  <br/><br/>  <br/><br/>
      <div className="content">
        {loading ? (
          <div className="text-center">
            <Spinner animation="border" variant="primary" />
            <p>Loading posts...</p>
          </div>
        ) : error ? (
          <Alert variant="danger" className="text-center">
            {error}
          </Alert>
        ) : (
          <div className="row">
            {posts.length > 0 ? (
              posts.map((post) => (
                <div className="col-lg-8 col-md-12 mb-4" key={post.post_id}>
                  <BlogCard
                    post_id={post.post_id}
                    title={post.title}
                    content={post.content}
                    imgSrc={post.image}
                    userProfile={post.profile_pic || "https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"}
                    username={post.username}
                    date={new Date(post.created_at).toLocaleDateString()}
                    initialLikes={post.n_likes}
                    initialDislikes={post.n_dislikes}
                  />
                </div>
              ))
            ) : (
              <p className="text-center">No posts available</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Home;
