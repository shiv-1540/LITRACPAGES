import React, { useEffect, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faComments, faHeart, faThumbsDown, faUserTimes } from '@fortawesome/free-solid-svg-icons';
import { useNavigate, useParams } from 'react-router-dom';

const AdminHome = () => {
  const [posts, setPosts] = useState([]);
  const navigate = useNavigate();
  const { username } = useParams();

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      const response = await fetch('http://localhost:3001/home/posts');
      const data = await response.json();
      setPosts(data);
    } catch (error) {
      console.error('Error fetching posts:', error);
    }
  };

  const disablePost = async (post_id) => {
    try {
      await fetch('http://localhost:3001/api/posts/disable', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ post_id }),
      });
      alert('The post has been disabled.');
      fetchPosts();
    } catch (error) {
      console.error('Error disabling post:', error);
    }
  };

  const disableUser = async (user_id) => {
    try {
      await fetch('http://localhost:3001/api/users/disable', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ user_id }),
      });
      alert('The user has been disabled.');
      fetchPosts();
    } catch (error) {
      console.error('Error disabling user:', error);
    }
  };

  const increaseCount = (e, type, post_id) => {
    const countElement = e.currentTarget.querySelector('b');
    const count = parseInt(countElement.textContent, 10);
    countElement.textContent = count + 1;
  };

  return (
    <div className="container bg-light">
      <header className="text-center my-4 d-flex justify-content-between align-items-center">
        <div className="text-center">
          <h1><b>LITARC</b> <span className="playwrite-cl">PAGES</span></h1>
          <p style={{ fontSize: '0.75em', marginTop: 0 }}>BRINGING WORDS TO LIFE</p>
        </div>
        <span className="badge" style={{ fontSize: '1.5em' }}>Raj Mehta
          <div onClick={() => {
            navigate(`/admin/dashboard/${username}`);
          }}>
            <img
              src="https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
              alt="Profile Picture"
              className="profile-picture"
            />
          </div>
        </span>
      </header>

      <div className="row">
        <div className="col-lg-8 col-md-12 mb-4 blog-entries">
          {posts.map((post) => (
            <div className="card mb-4" key={post.post_id}>
              <img
                src={post.image ? `data:image/jpeg;base64,${post.image}` : 'default-post-image.jpg'}
                className="card-img-top rounded-0"
                alt={post.title}
              />
              <div className="card-body">
                <div className="d-flex align-items-center mb-3">
                  <img
                    src={post.profimg ? `data:image/jpeg;base64,${post.profimg}` : 'default-profile-picture.jpg'}
                    alt="User Profile"
                    className="profile-picture2 mr-2"
                  />
                  <p className="mb-0">{post.username}</p>
                  <button
                    className="btn btn-danger btn-sm ml-auto disable-user-btn"
                    onClick={() => disableUser(post.user_id)}
                  >
                    <FontAwesomeIcon icon={faUserTimes} /> Disable User
                  </button>
                </div>
                <h3 className="card-title"><b>{post.title}</b></h3>
                <h5 className="card-subtitle mb-2 text-muted">{post.category}, <span className="text-muted">{new Date(post.created_at).toLocaleDateString()}</span></h5>
                <p className="card-text blog-content">
                  {post.content}
                </p>
                <div className="d-flex justify-content-between align-items-center">
                  <button className="btn btn-outline-primary btn-sm read-more-btn">READ MORE »</button>
                  <div>
                    <button
                      className="btn btn-sm btn-outline-secondary comment-btn"
                    >
                      <FontAwesomeIcon icon={faComments} /> <b>10</b> Comments
                    </button>
                    <button
                      className="btn btn-sm btn-outline-secondary like-btn"
                      onClick={(e) => increaseCount(e, 'like', post.post_id)}
                    >
                      <FontAwesomeIcon icon={faHeart} /> <b>{post.n_likes}</b> Likes
                    </button>
                    <button
                      className="btn btn-sm btn-outline-secondary dislike-btn"
                      onClick={(e) => increaseCount(e, 'dislike', post.post_id)}
                    >
                      <FontAwesomeIcon icon={faThumbsDown} /> <b>{post.n_dislikes}</b> Dislikes
                    </button>
                  </div>
                </div>
                <button
                  className="btn btn-warning btn-sm mt-2 disable-post-btn"
                  onClick={() => disablePost(post.post_id)}
                >
                  Disable Post
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="col-lg-4 col-md-12 mb-4">
          <div className="card">
            <div className="card-body">
              <h4 className="card-title">About Me</h4>
              <p className="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus imperdiet, nulla et dictum interdum, nisi lorem egestas odio, vitae scelerisque enim ligula venenatis dolor.</p>
            </div>
          </div>
          <div className="mt-3" onClick={() => {
            navigate(`/admin/dashboard/${username}`);
          }}>
            <button className="btn btn-primary btn-block">Dashboard</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminHome;
