import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import {
    Navbar,
    Nav,
    Container,
    Table,
    Button,
    Form,
    Dropdown,
    Spinner,
    Alert
} from 'react-bootstrap';
import './dash.css';

const AdminDashboard = () => {
    const [users, setUsers] = useState([]);
    const [roles, setRoles] = useState([]);
    const [selectedRole, setSelectedRole] = useState('1'); // Default to Admin role
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const navigate = useNavigate();

    // Fetch roles and users when the component mounts or selectedRole changes
    useEffect(() => {
        const fetchRoles = async () => {
            try {
                const response = await axios.get('http://localhost:3001/admin/roles');
                setRoles(response.data);
            } catch (error) {
                setError('Error fetching roles');
                console.error('Error fetching roles:', error);
            }
        };

        const fetchUsers = async () => {
            setLoading(true);
            try {
                const response = await axios.get(`http://localhost:3001/admin/users/role/${selectedRole}`);
                setUsers(response.data);
            } catch (error) {
                setError('Error fetching users');
                console.error('Error fetching users:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchRoles();
        fetchUsers();
    }, [selectedRole]);

    // Handle user status change (enable/disable)
    const handleStatusChange = async (userId, newStatus) => {
      try {
          const response = await axios.put(`http://localhost:3001/admin/users/status/${userId}`, { status: newStatus });
          if (response.status === 200) {
              setUsers(users.map(user => 
                  user.user_id === userId ? { ...user, disabled_admin: newStatus } : user
              ));
          } else {
              setError('Failed to update status. Please try again.');
          }
      } catch (error) {
          setError('Error updating user status');
          console.error('Error updating user status:', error);
      }
  };
  

    // Handle user role change
    const handleRoleChange = async (userId, newRoleId) => {
        try {
            const response = await axios.put(
                `http://localhost:3001/admin/users/role/${userId}`,
                { roleid: newRoleId }
            );

            if (response.status === 200) {
                // Update the users state with the new roleid
                setUsers(users.map(user => 
                    user.user_id === userId ? { ...user, roleid: response.data.roleid } : user
                ));
            } else {
                setError('Failed to update user role');
            }
        } catch (error) {
            setError('Error updating user role');
            console.error('Error updating user role:', error);
        }
    };

    // Handle logout action
    const handleLogout = async () => {
        try {
            await axios.post('http://localhost:3001/logout'); // Ensure this route exists
            alert('Logout Successfully!');
            navigate('/login');
        } catch (error) {
            console.error('Error during logout:', error);
            setError('Error during logout');
        }
    };

    return (
        <>
            {/* Navigation Bar */}
            <Navbar bg="dark" variant="dark" expand="lg">
                <Container>
                    <Navbar.Brand href="/">Admin Dashboard</Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="ml-auto">
                            <Nav.Link href="/">Home</Nav.Link>
                            <Dropdown alignRight>
                                <Dropdown.Toggle variant="success" id="dropdown-basic">
                                    <img
                                        src="https://via.placeholder.com/30"
                                        alt="Profile"
                                        className="rounded-circle"
                                    />
                                </Dropdown.Toggle>

                                <Dropdown.Menu>
                                    <Dropdown.Item href="/profile">Profile</Dropdown.Item>
                                    <Dropdown.Item onClick={handleLogout}>Logout</Dropdown.Item>
                                </Dropdown.Menu>
                            </Dropdown>
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>

            {/* Main Content */}
            <Container className="mt-5">
                <h2>Admin Dashboard</h2>

                {/* Error Alert */}
                {error && <Alert variant="danger">{error}</Alert>}

                {/* Role Filter */}
                <Form.Group controlId="roleSelect">
                    <Form.Label>Filter by Role:</Form.Label>
                    <Form.Control
                        as="select"
                        value={selectedRole}
                        onChange={(e) => setSelectedRole(e.target.value)}
                    >
                        {roles.map(role => (
                            <option key={role.role_id} value={role.role_id}>
                                {role.role_name}
                            </option>
                        ))}
                    </Form.Control>
                </Form.Group>

                {/* Users Table */}
                {loading ? (
                    <div className="text-center mt-3">
                        <Spinner animation="border" />
                    </div>
                ) : (
                    <Table striped bordered hover className="mt-3">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Status</th>
                                <th>Role</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {users.map(user => (
                                <tr key={user.user_id}>
                                    <td>{user.user_id}</td>
                                    <td>{user.username}</td>
                                    <td>{user.email}</td>
                                    <td>{user.disabled_admin === 0 ? 'Enabled' : 'Disabled'}</td>
                                    <td>
                                        <Form.Control
                                            as="select"
                                            value={user.roleid}
                                            onChange={(e) => handleRoleChange(user.user_id, parseInt(e.target.value))}
                                        >
                                            {roles.map(role => (
                                                <option key={role.role_id} value={role.role_id}>
                                                    {role.role_name}
                                                </option>
                                            ))}
                                        </Form.Control>
                                    </td>
                                    <td>
                                        <Button
                                            variant={user.disabled_admin === 0 ? 'danger' : 'success'}
                                            onClick={() => handleStatusChange(user.user_id, user.disabled_admin)}
                                        >
                                            {user.disabled_admin === 0 ? 'Disable' : 'Enable'}
                                        </Button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                )}
            </Container>
        </>
    );
};

export default AdminDashboard;
