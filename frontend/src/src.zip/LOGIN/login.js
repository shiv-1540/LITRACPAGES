import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import "./login.css";

function Login() {
    // State to manage username and password
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    const loginHandler = async (event) => {
        event.preventDefault();
    
        if (!username || !password) {
            alert('Username and password are required!');
            return;
        }
    
        try {
            const response = await fetch('http://localhost:3001/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password }),
                credentials: 'include' // Ensure cookies are sent with the request
            });
    
            if (response.ok) {
                const data = await response.json();
                alert('Login successful!');
    
                // Store session information in localStorage
                localStorage.setItem('user_id', data.user.user_id);
                localStorage.setItem('username', data.user.username);
                localStorage.setItem('roleid', data.user.roleid);
                localStorage.setItem('isLoggedIn', true);
    
                // Navigate based on user role
                if (data.user.roleid === 1) {
                    navigate('/admin/home');
                } else {
                    navigate('/home');
                }
            } else {
                const error = await response.json();
                alert(error.message || 'Login failed!');
            }
        } catch (error) {
            console.error('Login error:', error);
            alert('Login failed!');
        }
    };
    

    return (
        <div>
            <section>
                <div className="signin">
                    <div className="content">
                        <h2>Sign In</h2>
                        <form className="form" onSubmit={loginHandler}>
                            <div className="inputBox">
                                <input
                                    type="text"
                                    name="username"
                                    required
                                    value={username}
                                    onChange={(e) => setUsername(e.target.value)}
                                    placeholder='Username'
                                />
                            </div>
                            <div className="inputBox">
                                <input
                                    type="password"
                                    name="password"
                                    required
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    placeholder='Password'
                                />
                            </div>
                            <div className="links">
                                <a href="#">Forgot Password</a>
                                <a href="#" onClick={() => navigate('/signup')}>Signup</a>
                            </div>
                            <div className="inputBox">
                                <input type="submit" value="Login" />
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    );
}

export default Login;
