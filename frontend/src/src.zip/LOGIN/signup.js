import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import "./login.css";

function SignUp() {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        username: '',
        firstname: '',
        lastname: '',
        email: '',
        password: '',
        confirm_password: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const signUpHandler = async (event) => {
        event.preventDefault();
        console.log(formData);

        if (formData.password !== formData.confirm_password) {
            alert('Passwords do not match!');
            return;
        }

        try {
            const response = await fetch('http://localhost:3001/signup', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    username: formData.username,
                    firstname: formData.firstname,
                    lastname: formData.lastname,
                    email: formData.email,
                    password: formData.password
                })
            });

            if (response.ok) {
                const data = await response.json();
                console.log('User registered:', data);
                alert('Registration successful!');

                // Store session information in localStorage
                localStorage.setItem('session', JSON.stringify(data));

                // Navigate to the appropriate page based on the user's role
                if (data.roleid === 1) {
                    navigate(`/admin/home/${formData.username}`);
                } else {
                    navigate(`/home/${formData.username}`);
                }
            } else {
                const error = await response.json();
                console.error('Registration error:', error.message);
                alert(error.message || 'Registration failed!');
            }
        } catch (error) {
            console.error('Network error:', error);
            alert('Network error! Please try again later.');
        }
    };

    return (
        <div>
            {/* Sign Up */}
            <section>
                <div className="signup" >
                    <div className="content">
                        <h2 className="form__title">Sign Up</h2>
                        <form className="form" id="form1" onSubmit={signUpHandler}>
                            <div className="inputBox">
                                <input
                                    type="text"
                                    name="username"
                                    placeholder="Username"
                                    required
                                    value={formData.username}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className="inputBox">
                                <input
                                    type="text"
                                    name="firstname"
                                    placeholder="First Name"
                                    required
                                    value={formData.firstname}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className="inputBox">
                                <input
                                    type="text"
                                    name="lastname"
                                    placeholder="Last Name"
                                    required
                                    value={formData.lastname}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className="inputBox">
                                <input
                                    type="email"
                                    name="email"
                                    placeholder="E-mail"
                                    required
                                    value={formData.email}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className="inputBox">
                                <input
                                    type="password"
                                    name="password"
                                    placeholder="Create Password"
                                    required
                                    value={formData.password}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className="inputBox">
                                <input
                                    type="password"
                                    name="confirm_password"
                                    placeholder="Confirm Password"
                                    required
                                    value={formData.confirm_password}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className="inputBox">
                                <input type="submit" value="Sign up" />
                            </div>
                        </form>
                        <div className="links">
                            <span><a href="#" onClick={() => navigate('/login')}>Back to Login</a></span>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
}

export default SignUp;
