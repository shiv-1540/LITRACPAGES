import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './userposts.css'; // Import the CSS file

const UserPosts = () => {
    const userId = localStorage.getItem('user_id');
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchPosts = async () => {
            try {
                const response = await axios.get(`http://localhost:3001/user-posts/${userId}`);
                setPosts(response.data.posts);
            } catch (err) {
                setError('Error fetching posts');
            } finally {
                setLoading(false);
            }
        };

        fetchPosts();
    }, [userId]);

    if (loading) return <div>Loading...</div>;
    if (error) return <div>{error}</div>;

    return (
        <div className="posts-container" id="container">
            <h2>User Posts</h2>
            {posts.length === 0 ? (
                <p>No posts found.</p>
            ) : (
                posts.map(post => (
                    <div key={post.id} className="post-card">
                        <div className="post-header">
                            <img 
                                src={post.profile_pic} 
                                alt={`${post.username}'s profile`} 
                                className="profile-pic"
                            />
                            <p className="username">{post.username}</p>
                        </div>
                        <h3 className="post-title">{post.title}</h3>
                        <p className="content">{post.content}</p>
                        {post.image && <img src={post.image} alt="Post" className="post-image" />}
                    </div>
                ))
            )}
        </div>
    );
};

export default UserPosts;
