import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Modal, Button, Form } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import UserPosts from './usersposts';

const Profile = () => {
  const [showCreatePostModal, setShowCreatePostModal] = useState(false);
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);
  const [settingsMenuOpen, setSettingsMenuOpen] = useState(false);
  const [user, setUser] = useState({});
  const [newPost, setNewPost] = useState({
    title: '',
    content: '',
    category: '',
    image: null,
  });
  const [username, setUsername] = useState('');
  const [bio, setBio] = useState('');
  const [lastname, setLastname] = useState('');
  const [firstname, setFirstname] = useState('');
  const [profileImage, setProfileImage] = useState(null);

  const navigate = useNavigate();

  // Fetch profile data when the edit profile modal is shown
  useEffect(() => {
    if (showEditProfileModal) {
      fetchProfileData();
    }
  }, [showEditProfileModal]);

  const fetchProfileData = async () => {
    try {
      const user_id=localStorage.getItem('user_id');
      const response = await axios.get(`http://localhost:3001/profile/${user_id}`);
      const { username, bio, lastname, firstname, profile_pic } = response.data;

      setUsername(username);
      setBio(bio);
      setLastname(lastname);
      setFirstname(firstname);
      setProfileImage(profile_pic); // Assuming you want to display the current profile image
    } catch (error) {
      console.error('Error fetching profile data:', error);
    }
  };

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        // Retrieve user_id from localStorage
        const user_id = localStorage.getItem('user_id');
        if (!user_id) {
          navigate('/login');
          return;
        }

        // Fetch user data
        const response = await fetch(`http://localhost:3001/profile/${user_id}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
        });

        const data = await response.json();
        setUser(data);
        console.log("Data",data);
         // Convert Buffer data to Base64 string
         const base64String = btoa(
          new Uint8Array(data.profile_pic.data).reduce(
            (data, byte) => data + String.fromCharCode(byte),
            ''
          )
        );
        
        setUser({
          ...data,
          profileImageUrl: `data:image/jpeg;base64,${base64String}`, // Adjust MIME type if necessary
        });

      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    fetchUserData();
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('user_id');
    localStorage.removeItem('username');
    localStorage.removeItem('roleid');
    localStorage.removeItem('isLoggedIn');
    navigate('/login');
  };

  const handleCreatePost = async () => {
    const formData = new FormData();
    formData.append('title', newPost.title);
    formData.append('content', newPost.content);
    formData.append('category', newPost.category);
    if (newPost.image) formData.append('image', newPost.image);

    try {
      const user_id = localStorage.getItem('user_id');
      const response = await fetch(`http://localhost:3001/profile/createpost/${user_id}`, {
        method: 'POST',
        body: formData,
        credentials: 'include', // Ensure session data (like cookies) is sent with the request
      });

      if (response.status === 200) {
        alert('Post created successfully.');
        setNewPost({ title: '', content: '', category: '', image: null });
      } else {
        alert('Failed to create post.');
      }
    } catch (error) {
      console.error('Error creating post:', error);
      alert('An error occurred while creating the post.');
    }
  };

  const handleSaveProfile = async () => {
    const formData = new FormData();
    formData.append('username', username);
    formData.append('bio', bio);
    formData.append('lastname', lastname);
    formData.append('firstname', firstname);
    if (profileImage) {
      formData.append('image', profileImage);
    }

    try {
      const user_id=localStorage.getItem('user_id');
      const response = await axios.post(`http://localhost:3001/edit-profile/${user_id}`, formData);
      if (response.status === 200) {
        console.log('Profile updated successfully');
      } else {
        console.error('Failed to update profile');
      }
    } catch (error) {
      console.error('Error:', error);
    }

    setShowEditProfileModal(false);
  };

  return (
    <>
   
    <header className="fixed-header">
    <div className="logo-container">
      <b>LITARC-PAGES</b>
      <p className="tagline">BRINGING WORDS TO LIFE</p>
    </div>
    <div className="d-flex justify-content-center align-items-center">
      <Button className="btn btn-danger" onClick={handleLogout}>Logout</Button>
      <Button variant="link" onClick={() => navigate(`/profile/${user.user_id}`)}>
        <img
          src="https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
          alt="Profile Picture"
          className="profile-picture rounded-circle ml-3"
        />
      </Button>
    </div>
  </header>
   
    <div className="container mt-1">
     {/* <h2>Welcome to LITARC PAGES, {user.username}</h2>*/ }

      <Button className="settings-button" onClick={() => setSettingsMenuOpen(!settingsMenuOpen)}>
        <i className="fas fa-cog"></i> Settings
      </Button>

      <div className="profile-header">
        <div className="d-flex justify-content-between flex-row align-items-center gap-10 ">
         
          <img
            src={user.profileImageUrl }
            alt="Profile Picture"
            className="profile-picture " style={{ height: '150px',width:'180px' }}
          />
          <div className='text-white p-3 d-flex justify-content-center align-items-center flex-column flex-wrap '>
              <div className='d-flex align-items-center justify-content-center flex-column text-align-center'>
                <h3>{user.username}</h3>
                <p>{user.firstname} {user.lastname}</p>
              </div> 
              <p className='w-50'>{user.bio}</p>
          </div>
           <div className='d-flex flex-column gap-5'>
             <Button variant="light" onClick={() => setShowEditProfileModal(true)}>
                <i className="fas fa-edit"></i> Edit Profile
             </Button>
             <Button variant="light" className='bg-success' onClick={() => setShowCreatePostModal(true)}>
                <i className="fas fa-plus"></i> Create Post
             </Button>
             <Button variant="danger" className='bg-danger' onClick={handleLogout}>
                <i className="fas fa-sign-out-alt "></i> Logout
             </Button>
           </div> 
        </div>
      </div>

      {/* Create Post Modal */}
      <Modal show={showCreatePostModal} onHide={() => setShowCreatePostModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Create Post</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group controlId="postTitle">
              <Form.Label>Title</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter post title"
                value={newPost.title}
                onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
              />
            </Form.Group>
            <Form.Group controlId="postContent">
              <Form.Label>Content</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                placeholder="Enter post content"
                value={newPost.content}
                onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
              />
            </Form.Group>
            <Form.Group controlId="postCategory">
              <Form.Label>Category</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter post category"
                value={newPost.category}
                onChange={(e) => setNewPost({ ...newPost, category: e.target.value })}
              />
            </Form.Group>
            <Form.Group controlId="postImage">
              <Form.Label>Upload Image</Form.Label>
              <Form.Control
                type="file"
                onChange={(e) => setNewPost({ ...newPost, image: e.target.files[0] })}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowCreatePostModal(false)}>Close</Button>
          <Button variant="primary" onClick={handleCreatePost}>Save Post</Button>
        </Modal.Footer>
      </Modal>

      {/* Edit Profile Modal */}
      <Modal show={showEditProfileModal} onHide={() => setShowEditProfileModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Edit Profile</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group controlId="username">
              <Form.Label>Username</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
            </Form.Group>
            <Form.Group controlId="firstname">
              <Form.Label>First Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter first name"
                value={firstname}
                onChange={(e) => setFirstname(e.target.value)}
              />
            </Form.Group>
            <Form.Group controlId="lastname">
              <Form.Label>Last Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter last name"
                value={lastname}
                onChange={(e) => setLastname(e.target.value)}
              />
            </Form.Group>
            <Form.Group controlId="bio">
              <Form.Label>Bio</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                placeholder="Enter bio"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
              />
            </Form.Group>
            <Form.Group controlId="profileImage">
              <Form.Label>Upload Image</Form.Label>
              <Form.Control
                type="file"
                onChange={(e) => setProfileImage(e.target.files[0])}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowEditProfileModal(false)}>Close</Button>
          <Button variant="primary" onClick={handleSaveProfile}>Save Profile</Button>
        </Modal.Footer>
      </Modal>
    </div>

    <UserPosts/>
     </>
  );
  
};

export default Profile;
