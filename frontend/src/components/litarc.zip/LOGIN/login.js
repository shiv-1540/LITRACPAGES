import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
//import './login.css'; // Remove this line if you're not using custom CSS anymore

function Login() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    const navigate = useNavigate();

    const loginHandler = async (event) => {
        event.preventDefault();

        if (!username || !password) {
            alert('Username and password are required!');
            return;
        }

        try {
            const response = await fetch('http://localhost:3001/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password }),
                credentials: 'include'
            });

            if (response.ok) {
                const data = await response.json();
                setSuccessMessage('Login successful! Redirecting...');
                
                // Store session information in localStorage
                localStorage.setItem('user_id', data.user.user_id);
                localStorage.setItem('username', data.user.username);
                localStorage.setItem('roleid', data.user.roleid);
               

                // Convert Buffer data to Base64 string
                const base64String = btoa(
                    new Uint8Array(data.user.profile_pic).reduce(
                        (data, byte) => data + String.fromCharCode(byte),
                        ''
                    )
                );
                const profileImageUrl = `data:image/jpeg;base64,${base64String}`;
                localStorage.setItem('profile_pic', profileImageUrl);

                localStorage.setItem('isLoggedIn', true);

                // Navigate based on user role after a short delay for message
                setTimeout(() => {
                    if (data.user.roleid === 1) {
                        navigate(`/admin/home/${username}`);
                    } else {
                        navigate('/home');
                    }
                }, 2000);
            } else {
                const error = await response.json();
                alert(error.message || 'Login failed!');
            }
        } catch (error) {
            console.error('Login error:', error);
            alert('Login failed!');
        }
    };

    return (
        <div className="flex justify-center items-center  h-screen bg-gray-100">
            <div className="w-full max-w-md p-8 space-y-8 bg-white shadow-lg rounded-lg">
                <h2 className="text-2xl font-bold text-center text-gray-900">Sign In</h2>
                
                {successMessage && (
                    <div className="bg-green-100 text-green-800 px-4 py-2 rounded">
                        {successMessage}
                    </div>
                )}

                <form className="mt-6" onSubmit={loginHandler}>
                    <div className="mb-4">
                        <input
                            type="text"
                            name="username"
                            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-indigo-200"
                            required
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            placeholder="Username"
                        />
                    </div>
                    <div className="mb-4">
                        <input
                            type="password"
                            name="password"
                            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-indigo-200"
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Password"
                        />
                    </div>
                    <div className="flex justify-between items-center mb-6">
                        <a href="#" className="text-sm text-indigo-600 hover:underline">Forgot Password?</a>
                        <a href="#" onClick={() => navigate('/signup')} className="text-sm text-indigo-600 hover:underline">Signup</a>
                    </div>
                    <button
                        type="submit"
                        className="w-full px-4 py-2 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 transition-colors"
                    >
                        Login
                    </button>
                </form>
            </div>
        </div>
    );
    
}

export default Login;
