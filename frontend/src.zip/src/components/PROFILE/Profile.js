import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Modal, Button, Form } from 'react-bootstrap';


const Profile = () => {
  const [showCreatePostModal, setShowCreatePostModal] = useState(false);
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);
  const [settingsMenuOpen, setSettingsMenuOpen] = useState(false);

  // Sample user data
  const user = {
    profilePicture: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    username: 'Sayujio',
    fullName: 'Sayuj Singh',
    bio: 'A photographer and writer with a passion for capturing the world and telling stories that hit different. Armed with a camera and a pen, I\'m all about creating content that vibes.',
  };

  return (
    <div className="container mt-5">
      <Button className="settings-button" onClick={() => setSettingsMenuOpen(!settingsMenuOpen)}>
        <i className="fas fa-cog"></i> Settings
      </Button>

      <div className="profile-header">
        <div className="left">
          <img src={user.profilePicture} alt="Profile Picture" className="profile-picture" />
          <div>
            <h3>{user.username}</h3>
            <p>{user.fullName}</p>
          </div>
          <Button variant="light" onClick={() => setShowEditProfileModal(true)}>
            <i className="fas fa-edit"></i> Edit Profile
          </Button>
        </div>
      </div>

      <div className="mb-4">
        <h4>About</h4>
        <p>{user.bio}</p>
        <p>🎃📸</p>
      </div>

      <div className="action-buttons mb-4">
        <Button variant="light" onClick={() => setShowCreatePostModal(true)}>
          <i className="fas fa-plus"></i> Create Post
        </Button>
        <Button variant="light">
          <i className="fas fa-archive"></i> View Archive
        </Button>
      </div>

      <div className="row">
        <div className="col-lg-8 col-md-12">
          {/* Blog entries */}
          {/* Blog entry 1 */}
          <div className="card mb-4">
            <img src="https://images.pexels.com/photos/547115/pexels-photo-547115.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" className="card-img-top rounded-0" alt="Mountains" />
            <div className="card-body">
              <h3 className="card-title"><b>MOUNTAINS</b></h3>
              <h5 className="card-subtitle mb-2 text-muted">Majestic Heights, <span className="text-muted">July 15, 2024</span></h5>
              <p className="card-text blog-content">Explore the grandeur of towering mountains and the serenity they offer. From breathtaking peaks to tranquil valleys, mountains hold a unique charm that captivates the heart of every adventurer.</p>
              <div className="d-flex justify-content-between align-items-center">
                <Button variant="outline-primary" size="sm">READ MORE »</Button>
                <div>
                  <span className="comment-count"><i className="fas fa-comments"></i> <b>10</b></span>
                  <span className="like-count"><i className="fa fa-heart like-icon"></i> <b>0</b></span>
                  <span className="dislike-icon"><i className="fa fa-thumbs-down"></i> <b>0</b></span>
                </div>
              </div>
            </div>
          </div>
          {/* Repeat for other blog entries */}
        </div>

        <div className="col-lg-4 col-md-12">
          <div className="popular-posts mb-4">
            <div className="card mb-4">
              <div className="card-header">
                <h4>Most Reached</h4>
              </div>
              <ul className="list-group list-group-flush">
                {/* Popular posts list items */}
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Settings Menu */}
      <div className={`settings-menu ${settingsMenuOpen ? 'open' : ''}`}>
        <Button className="close-settings-button" onClick={() => setSettingsMenuOpen(false)}>&times;</Button>
        <h4>Settings</h4>
        <ul className="list-group">
          <li className="list-group-item">Profile Settings</li>
          <li className="list-group-item">Account Settings</li>
          <li className="list-group-item">Privacy Settings</li>
          <li className="list-group-item">Notification Settings</li>
        </ul>
      </div>

      {/* Create Post Modal */}
      <Modal show={showCreatePostModal} onHide={() => setShowCreatePostModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Create Post</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group controlId="postTitle">
              <Form.Label>Title</Form.Label>
              <Form.Control type="text" placeholder="Enter post title" />
            </Form.Group>
            <Form.Group controlId="postContent">
              <Form.Label>Content</Form.Label>
              <Form.Control as="textarea" rows={3} placeholder="Enter post content" />
            </Form.Group>
            <Form.Group controlId="postImage">
              <Form.Label>Upload Image</Form.Label>
              <Form.File />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowCreatePostModal(false)}>Close</Button>
          <Button variant="primary">Save Post</Button>
        </Modal.Footer>
      </Modal>

      {/* Edit Profile Modal */}
      <Modal show={showEditProfileModal} onHide={() => setShowEditProfileModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Edit Profile</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group controlId="profilePicture">
              <Form.Label>Profile Picture</Form.Label>
              <Form.File />
            </Form.Group>
            <Form.Group controlId="username">
              <Form.Label>Username</Form.Label>
              <Form.Control type="text" placeholder="Enter username" />
            </Form.Group>
            <Form.Group controlId="fullName">
              <Form.Label>Full Name</Form.Label>
              <Form.Control type="text" placeholder="Enter full name" />
            </Form.Group>
            <Form.Group controlId="bio">
              <Form.Label>Bio</Form.Label>
              <Form.Control as="textarea" rows={3} placeholder="Enter bio" />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowEditProfileModal(false)}>Close</Button>
          <Button variant="primary">Save Changes</Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default Profile;
