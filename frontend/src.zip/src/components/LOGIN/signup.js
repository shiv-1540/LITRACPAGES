import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';


function SignUp() {
   // const [isSignUp, setIsSignUp] = useState(false);

    // State to manage form data
    const [formData, setFormData] = useState({
        full_name: '',
        email: '',
        mobile: '',
        username: '',
        password: '',
        confirm_password: '',
        user_type: ''
    });

   // const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

   // const handleSignIn = () => setIsSignUp(false);
   // const handleSignUp = () => setIsSignUp(true);

    const signUpHandler = async (event) => {
        event.preventDefault();
    
        if (formData.password !== formData.confirm_password) {
            alert('Passwords do not match!');
            return;
        }
       
            const response = await fetch('http://localhost:3001/signup', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    username: formData.username,
                    firstname: formData.firstname,
                    lastname: formData.lastname,
                    email: formData.email,
                    password: formData.password,
                    bio: formData.bio
                })
            });
            console.log(response)
            if (response.ok) {
                const data = await response.json();
                console.log('User registered:', data);
                alert('Registration successful!');
                // navigate('/login');
            } else {
                const error = await response.json();
                console.error('Registration error:', error.message);
                alert(error.message || 'Registration failed!');
            }
       
    };

    return (
        <div>
            {/* Sign Up */}
            <div className="container__form container--signup">
                <form className="form" id="form1" onSubmit={signUpHandler}>
                    <h2 className="form__title">Sign Up</h2>
                    
                    <input
                        type="text"
                        name="username"
                        placeholder="Username"
                        required
                        value={formData.username}
                        onChange={handleChange}
                    />
                    <input
                        type="text"
                        name="firstname"
                        placeholder="First Name"
                        required
                        value={formData.firstname}
                        onChange={handleChange}
                    />
                    <input
                    type="text"
                    name="lastname"
                    placeholder="Last Name"
                    required
                    value={formData.lastname}
                    onChange={handleChange}
                />
                    <input
                        type="email"
                        name="email"
                        placeholder="E-mail"
                        required
                        value={formData.email}
                        onChange={handleChange}
                    />
                  
                    <input
                        type="password"
                        name="password"
                        placeholder="Create Password"
                        required
                        value={formData.password}
                        onChange={handleChange}
                    />
                    <input
                        type="password"
                        name="confirm_password"
                        placeholder="Confirm Password"
                        required
                        value={formData.confirm_password}
                        onChange={handleChange}
                    />
                    <input
                    type="text"
                    name="bio"
                    placeholder="Bio"
                    required
                    value={formData.bio}
                    onChange={handleChange}
                />

                    <button className="btn" type="submit">Sign up</button>
                </form>
            </div>
        </div>
    );
}

export default SignUp;
