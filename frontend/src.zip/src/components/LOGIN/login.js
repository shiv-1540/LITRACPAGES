import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Login() {
    // State to manage form data
    const [formData, setFormData] = useState({
        username: '',
        password: ''
    });

 const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const loginHandler = async (event) => {
        event.preventDefault();

        if (!formData.username || !formData.password) {
            alert('Username and password are required!');
            return;
        }
            const response = await fetch('http://localhost:3001/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    username: formData.username,
                    password: formData.password
                })
            });

            console.log(response)
            if (response.ok) {
                const data = await response.json();
                console.log('Login successful:', data);
                alert('Login successful!');
                // Navigate to home page or another page after login
              navigate('/home');
            } 
            else {
                const error = await response.json();
                console.error('Login error:', error.message);
                alert(error.message || 'Login failed!');
            }
    };

    return (
        <div>
            {/* Login */}
            <div className="container__form container--login">
                <form className="form" id="form2" onSubmit={loginHandler}>
                    <h2 className="form__title">Login</h2>
                    
                    <input
                        type="text"
                        name="username"
                        placeholder="Username"
                        required
                        value={formData.username}
                        onChange={handleChange}
                    />
                    <input
                        type="password"
                        name="password"
                        placeholder="Password"
                        required
                        value={formData.password}
                        onChange={handleChange}
                    />

                    <button className="btn" type="submit">Login</button>
                </form>
            </div>
        </div>
    );
}

export default Login;
