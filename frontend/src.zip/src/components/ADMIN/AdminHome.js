import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './AdminHome.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faComments, faHeart, faThumbsDown, faUserTimes } from '@fortawesome/free-solid-svg-icons';

const AdminHome = () => {
  const disablePost = (e) => {
    e.currentTarget.closest('.card').style.display = 'none';
    alert('The post has been disabled.');
  };

  const disableUser = (e) => {
    e.currentTarget.closest('.card').style.display = 'none';
    alert('The user has been disabled.');
  };

  const increaseCount = (e, type) => {
    const countElement = e.currentTarget.querySelector('b');
    const count = parseInt(countElement.textContent, 10);
    countElement.textContent = count + 1;
  };

  return (
    <div className="container bg-light">
      {/* Header */}
      <header className="text-center my-4 d-flex justify-content-between align-items-center">
        <div className="text-center">
          <h1><b>LITARC</b> <span className="playwrite-cl">PAGES</span></h1>
          <p style={{ fontSize: '0.75em', marginTop: 0 }}>BRINGING WORDS TO LIFE</p>
        </div>
        <span className="badge" style={{ fontSize: '1.5em' }}>Raj Mehta
          <a href="/ADMIN/adminprofile.html">
            <img
              src="https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
              alt="Profile Picture"
              className="profile-picture"
            />
          </a>
        </span>
      </header>

      {/* Grid */}
      <div className="row">
        {/* Blog entries */}
        <div className="col-lg-8 col-md-12 mb-4 blog-entries">
          {/* Blog entry 1 */}
          <div className="card mb-4">
            <img
              src="https://images.pexels.com/photos/547115/pexels-photo-547115.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
              className="card-img-top rounded-0"
              alt="Mountains"
            />
            <div className="card-body">
              {/* User information */}
              <div className="d-flex align-items-center mb-3">
                <img
                  src="https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                  alt="User Profile"
                  className="profile-picture2 mr-2"
                />
                <p className="mb-0">Username</p>
                <button className="btn btn-danger btn-sm ml-auto disable-user-btn" onClick={disableUser}>
                  <FontAwesomeIcon icon={faUserTimes} /> Disable User
                </button>
              </div>
              {/* Blog content */}
              <h3 className="card-title"><b>MOUNTAINS</b></h3>
              <h5 className="card-subtitle mb-2 text-muted">Majestic Heights, <span className="text-muted">April 7, 2014</span></h5>
              <p className="card-text blog-content">
                Explore the grandeur of towering mountains and the serenity they offer. From breathtaking peaks to tranquil valleys, mountains hold a unique charm that captivates the heart of every adventurer.
              </p>
              <div className="d-flex justify-content-between align-items-center">
                <button className="btn btn-outline-primary btn-sm read-more-btn">READ MORE »</button>
                <div>
                  <button className="btn btn-sm btn-outline-secondary comment-btn">
                    <FontAwesomeIcon icon={faComments} /> <b>10</b> Comments
                  </button>
                  <button className="btn btn-sm btn-outline-secondary like-btn" onClick={(e) => increaseCount(e, 'like')}>
                    <FontAwesomeIcon icon={faHeart} /> <b>0</b> Likes
                  </button>
                  <button className="btn btn-sm btn-outline-secondary dislike-btn" onClick={(e) => increaseCount(e, 'dislike')}>
                    <FontAwesomeIcon icon={faThumbsDown} /> <b>0</b> Dislikes
                  </button>
                </div>
              </div>
              <button className="btn btn-warning btn-sm mt-2 disable-post-btn" onClick={disablePost}>Disable Post</button>
            </div>
          </div>

          {/* Blog entry 2 */}
          <div className="card mb-4">
            <img
              src="https://images.pexels.com/photos/250591/pexels-photo-250591.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
              className="card-img-top rounded-0"
              alt="Flowers"
            />
            <div className="card-body">
              {/* User information */}
              <div className="d-flex align-items-center mb-3">
                <img
                  src="https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                  alt="User Profile"
                  className="profile-picture2 mr-2"
                />
                <p className="mb-0">Username</p>
                <button className="btn btn-danger btn-sm ml-auto disable-user-btn" onClick={disableUser}>
                  <FontAwesomeIcon icon={faUserTimes} /> Disable User
                </button>
              </div>
              {/* Blog content */}
              <h3 className="card-title"><b>FLOWERS</b></h3>
              <h5 className="card-subtitle mb-2 text-muted">Blooming Beauty, <span className="text-muted">April 2, 2014</span></h5>
              <p className="card-text blog-content">
                Dive into the vibrant world of flowers. Discover the diversity of flora, from delicate petals to bold blossoms, each flower tells a story of nature's splendor and the cycle of life.
              </p>
              <div className="d-flex justify-content-between align-items-center">
                <button className="btn btn-outline-primary btn-sm read-more-btn">READ MORE »</button>
                <div>
                  <button className="btn btn-sm btn-outline-secondary comment-btn">
                    <FontAwesomeIcon icon={faComments} /> <b>10</b> Comments
                  </button>
                  <button className="btn btn-sm btn-outline-secondary like-btn" onClick={(e) => increaseCount(e, 'like')}>
                    <FontAwesomeIcon icon={faHeart} /> <b>0</b> Likes
                  </button>
                  <button className="btn btn-sm btn-outline-secondary dislike-btn" onClick={(e) => increaseCount(e, 'dislike')}>
                    <FontAwesomeIcon icon={faThumbsDown} /> <b>0</b> Dislikes
                  </button>
                </div>
              </div>
              <button className="btn btn-warning btn-sm mt-2 disable-post-btn" onClick={disablePost}>Disable Post</button>
            </div>
          </div>

          {/* Blog entry 3 */}
          <div className="card mb-4">
            <img
              src="https://images.pexels.com/photos/5326990/pexels-photo-5326990.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
              className="card-img-top rounded-0"
              alt="Deep Ocean"
            />
            <div className="card-body">
              {/* User information */}
              <div className="d-flex align-items-center mb-3">
                <img
                  src="https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                  alt="User Profile"
                  className="profile-picture2 mr-2"
                />
                <p className="mb-0">Username</p>
                <button className="btn btn-danger btn-sm ml-auto disable-user-btn" onClick={disableUser}>
                  <FontAwesomeIcon icon={faUserTimes} /> Disable User
                </button>
              </div>
              {/* Blog content */}
              <h3 className="card-title"><b>DEEP OCEANS</b></h3>
              <h5 className="card-subtitle mb-2 text-muted">Mysteries Beneath, <span className="text-muted">May 15, 2022</span></h5>
              <p className="card-text blog-content">
                Uncover the mysteries of the deep oceans. From the stunning coral reefs to the enigmatic sea creatures, the ocean depths are a world of wonder and intrigue, waiting to be explored.
              </p>
              <div className="d-flex justify-content-between align-items-center">
                <button className="btn btn-outline-primary btn-sm read-more-btn">READ MORE »</button>
                <div>
                  <button className="btn btn-sm btn-outline-secondary comment-btn">
                    <FontAwesomeIcon icon={faComments} /> <b>10</b> Comments
                  </button>
                  <button className="btn btn-sm btn-outline-secondary like-btn" onClick={(e) => increaseCount(e, 'like')}>
                    <FontAwesomeIcon icon={faHeart} /> <b>0</b> Likes
                  </button>
                  <button className="btn btn-sm btn-outline-secondary dislike-btn" onClick={(e) => increaseCount(e, 'dislike')}>
                    <FontAwesomeIcon icon={faThumbsDown} /> <b>0</b> Dislikes
                  </button>
                </div>
              </div>
              <button className="btn btn-warning btn-sm mt-2 disable-post-btn" onClick={disablePost}>Disable Post</button>
            </div>
          </div>
        </div>

        {/* Introduction menu */}
        <div className="col-lg-4 col-md-12 mb-4">
          <div className="card">
            <div className="card-body">
              <h4 className="card-title">About Me</h4>
              <p className="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus imperdiet, nulla et dictum interdum, nisi lorem egestas odio, vitae scelerisque enim ligula venenatis dolor.</p>
            </div>
          </div>

          {/* Dashboard Button */}
          <div className="mt-3">
            <a href="/ADMIN/admindashboard.html" className="btn btn-primary btn-block">Dashboard</a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminHome;
