import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'font-awesome/css/font-awesome.min.css';

const AdminDashboard = () => {
  return (
    <div className="bg-light">
      {/* Top container */}
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidebar" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <span className="navbar-brand mb-0 h1 ml-auto">LITARC PAGES ADMIN DASHBOARD</span>
      </nav>

      {/* Sidebar */}
      <div className="bg-white border-right" id="sidebar-wrapper">
        <div className="sidebar-heading text-center py-4">
          {/* <img src="/web pages/images/1.png" className="rounded-circle mb-3" alt="" /> */}
          <span>Welcome, <strong>Raj Mehta♥ </strong></span>
          <div className="btn-group mt-2">
            <a href="#" className="btn btn-outline-secondary"><i className="fa fa-envelope"></i></a>
            <a href="#" className="btn btn-outline-secondary"><i className="fa fa-user"></i></a>
            <a href="#" className="btn btn-outline-secondary"><i className="fa fa-cog"></i></a>
          </div>
        </div>
        <div className="list-group list-group-flush">
          <a href="#" className="list-group-item list-group-item-action bg-light"><i className="fa fa-ban fa-fw mr-2"></i>Disabled Blogs</a>
          <a href="#disabled-users-section" className="list-group-item list-group-item-action bg-light w3-bar-item w3-button w3-padding">
            <i className="fa fa-user-times fa-fw mr-2"></i> Disabled Users
          </a>
        </div>
      </div>

      {/* Page Content */}
      <div id="page-content-wrapper" className="container-fluid mt-5 pt-3">
        {/* Disabled Blogs Section */}
        <div id="disabled-blogs">
          <h5 className="mb-3"><b><i className="fa fa-ban"></i> Disabled Blogs</b></h5>
          <div className="row mb-4">
            {/* Blog post 1 */}
            <div className="col-12 mb-3">
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">The Wonders of Nature</h5>
                  <p className="card-text">Exploring the beauty of nature and its amazing wonders. Tips and guides for the perfect nature trip.</p>
                  <button className="btn btn-success">Enable</button>
                </div>
              </div>
            </div>
            {/* Blog post 2 */}
            <div className="col-12 mb-3">
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">Tech Innovations 2024</h5>
                  <p className="card-text">Latest innovations in technology and what to expect in the coming year. Stay ahead with our comprehensive guide.</p>
                  <button className="btn btn-success">Enable</button>
                </div>
              </div>
            </div>
            {/* Blog post 3 */}
            <div className="col-12 mb-3">
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">Healthy Living Tips</h5>
                  <p className="card-text">Your guide to a healthier lifestyle. Tips on diet, exercise, and mental wellness to keep you in top shape.</p>
                  <button className="btn btn-success">Enable</button>
                </div>
              </div>
            </div>
            {/* Blog post 4 */}
            <div className="col-12 mb-3">
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">Travel Diaries: Europe</h5>
                  <p className="card-text">Join us as we explore the hidden gems of Europe. A travel diary filled with adventures and travel tips.</p>
                  <button className="btn btn-success">Enable</button>
                </div>
              </div>
            </div>
            {/* Blog post 5 */}
            <div className="col-12 mb-3">
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">DIY Home Decor</h5>
                  <p className="card-text">Creative ideas and step-by-step guides to transform your home with DIY decor projects.</p>
                  <button className="btn btn-success">Enable</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Disabled Users Section */}
        <div id="disabled-users-section">
          <h5 className="mb-3"><b><i className="fa fa-user-times"></i> Disabled Users</b></h5>
          <input className="form-control mb-3" id="userSearch" type="text" placeholder="Search for users..." />
          <div className="list-group">
            {/* User 1 */}
            <div className="list-group-item d-flex justify-content-between align-items-center">
              <span>JohnDoe123</span>
              <button className="btn btn-success">Enable</button>
            </div>
            {/* User 2 */}
            <div className="list-group-item d-flex justify-content-between align-items-center">
              <span>JaneSmith456</span>
              <button className="btn btn-success">Enable</button>
            </div>
            {/* User 3 */}
            <div className="list-group-item d-flex justify-content-between align-items-center">
              <span>TravelerMike</span>
              <button className="btn btn-success">Enable</button>
            </div>
            {/* User 4 */}
            <div className="list-group-item d-flex justify-content-between align-items-center">
              <span>HealthGuru</span>
              <button className="btn btn-success">Enable</button>
            </div>
            {/* User 5 */}
            <div className="list-group-item d-flex justify-content-between align-items-center">
              <span>NatureLover</span>
              <button className="btn btn-success">Enable</button>
            </div>
            {/* User 6 */}
            <div className="list-group-item d-flex justify-content-between align-items-center">
              <span>GadgetGuy</span>
              <button className="btn btn-success">Enable</button>
            </div>
            {/* User 7 */}
            <div className="list-group-item d-flex justify-content-between align-items-center">
              <span>DIYQueen</span>
              <button className="btn btn-success">Enable</button>
            </div>
            {/* User 8 */}
            <div className="list-group-item d-flex justify-content-between align-items-center">
              <span>AdventureAlex</span>
              <button className="btn btn-success">Enable</button>
            </div>
            {/* User 9 */}
            <div className="list-group-item d-flex justify-content-between align-items-center">
              <span>FoodieFiona</span>
              <button className="btn btn-success">Enable</button>
            </div>
            {/* User 10 */}
            <div className="list-group-item d-flex justify-content-between align-items-center">
              <span>CoderCarl</span>
              <button className="btn btn-success">Enable</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
