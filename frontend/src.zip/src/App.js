import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Login from './components/LOGIN/login.js';
import SignUp from './components/LOGIN/signup.js';
import Home from './components/HOME/Home.js';
import Profile from './components/PROFILE/Profile'; // Assuming you have a Profile component
import CreatePost from './components/POST/createpost.js';
import MainProfile from './components/POST/mainprofile.js';
import "./components/POST/style.css";

function App() {
  return (
    <div className="App">
     <MainProfile />
    </div>
  );
}

export default App;
